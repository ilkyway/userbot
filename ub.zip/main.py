from telethon.sync import TelegramClient
from telethon.tl.functions.photos import UploadProfilePhotoRequest, DeletePhotosRequest
import random
import os
import time
api_id = 26930344
api_hash = '9718dcfcf3e56d1fc1c2bd0d3cc739ae'
name = "neol1tic"
client = TelegramClient(name, api_id, api_hash)
with TelegramClient(name, api_id, api_hash) as client:
	def DeleteAvatar():
		client(DeletePhotosRequest(client.get_profile_photos('me')))
	def ChangeAvatar(avatar):
		filea= client.upload_file(f'avatars/{avatar}')
		proc = UploadProfilePhotoRequest(filea)
		client(proc)
	def RandomAvatar():
	   print("[+]Choice avatar...")
	   file = random.choice(os.listdir('avatars/'))
	   print("[+]Delete old avatar...")
	   DeleteAvatar()
	   print("[+]Uplod new avatar...")
	   ChangeAvatar(file)
	   print("[+]Changed!")
	   print("[+]Sending Info message...")
	   try:
	   	client.send_message(entity=client.get_entity('https://t.me/neoliticavatars'),message=f"[INFO]Avatar Change to {file}")
	   except:
	   	print("[+]Sending Info message failed!")
	   print("[+]Successfully changed avatar!")
	   print("-----------------------------")
	def Connect():
		client.connect()

Connect()
while True:
	RandomAvatar()
	time.sleep(60)

client.start()
client.run_until_disconnected()